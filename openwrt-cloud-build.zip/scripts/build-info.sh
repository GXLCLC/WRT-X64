#!/bin/bash
# ===================================================================
# build-info.sh：收集固件信息，生成 release 页面 markdown
# -------------------------------------------------------------------
# 作用：编译完成后调用，从源码与 .config 提取：
#         - 固件版本、内核版本、编译日期、源码 commit
#         - 镜像文件名与大小
#         - 启用的插件清单（一行一个，不挤在一行）
#       输出到 /tmp/firmware-info.md，供 workflow 上传为 release 正文
# ===================================================================

# 进入 OpenWrt 源码目录
cd $HOME/openwrt || exit 1

# 输出文件路径（workflow 会从这里读取）
INFO_FILE="/tmp/firmware-info.md"

# ===================================================================
# 1. 获取固件版本号（如 OpenWrt 23.05.x、LEDE R24.x）
# -------------------------------------------------------------------
# OpenWrt 把发行版本写在 package/base-files/files/etc/openwrt_release
# 形如：DISTRIB_RELEASE='23.05.5'
# 备用：从 include/version.mk 取
# ===================================================================
FW_VERSION=""
RELEASE_FILE="package/base-files/files/etc/openwrt_release"
if [ -f "$RELEASE_FILE" ]; then
    FW_VERSION=$(grep -o "DISTRIB_RELEASE='[^']*'" "$RELEASE_FILE" | head -1 | cut -d"'" -f2)
fi
# 备用方案：从 include/version.mk 取
if [ -z "$FW_VERSION" ]; then
    FW_VERSION=$(grep -o 'DISTRIB_RELEASE=.*' include/version.mk 2>/dev/null | head -1 | cut -d"'" -f2)
fi
# 兜底：未知
[ -z "$FW_VERSION" ] && FW_VERSION="未知"

# ===================================================================
# 2. 获取内核版本（Linux Kernel 版本号）
# -------------------------------------------------------------------
# LEDE 把内核版本写在 target/linux/x86/Makefile 中
# 形如：KERNEL_PATCHVER:=6.6
# 精确小版本可从编译后的 build_dir 取
# ===================================================================
KERNEL_VER=""
# 方式 1：从 target/linux/x86/Makefile 取 KERNEL_PATCHVER
if [ -f target/linux/x86/Makefile ]; then
    KERNEL_VER=$(grep -oE 'KERNEL_PATCHVER[[:space:]]*:=[[:space:]]*[0-9.]+' target/linux/x86/Makefile | head -1 | awk '{print $NF}')
fi
# 方式 2：从 build_dir 取精确版本号（如 6.6.74）
if [ -z "$KERNEL_VER" ] || [ "$KERNEL_VER" = "" ]; then
    KERNEL_FILE=$(find build_dir -name "kernel.release" -type f 2>/dev/null | head -1)
    if [ -n "$KERNEL_FILE" ] && [ -f "$KERNEL_FILE" ]; then
        KERNEL_VER=$(cat "$KERNEL_FILE")
    fi
fi
# 兜底：未知
[ -z "$KERNEL_VER" ] && KERNEL_VER="未知"

# ===================================================================
# 3. 查找生成的 IMG 固件文件
# -------------------------------------------------------------------
# OpenWrt x86/64 产物在 bin/targets/x86/64/
# 主镜像文件名为 *combined-efi*squashfs*.img 或 .img.gz
# ===================================================================
IMG_DIR=$(find bin/targets -type d -name "64" -path "*x86*" | head -1)
# 找 combined-efi 镜像（含 bootloader+kernel+rootfs 的完整镜像）
COMBINED_IMG=$(find "$IMG_DIR" -name "*combined-efi*squashfs*" -name "*.img" -type f 2>/dev/null | head -1)
# 找不到就找任意 .img
if [ -z "$COMBINED_IMG" ]; then
    COMBINED_IMG=$(find "$IMG_DIR" -name "*.img" -type f 2>/dev/null | head -1)
fi
# 获取文件名与大小（人类可读，如 200M）
if [ -n "$COMBINED_IMG" ] && [ -f "$COMBINED_IMG" ]; then
    IMG_NAME=$(basename "$COMBINED_IMG")
    IMG_SIZE=$(du -h "$COMBINED_IMG" | cut -f1)
else
    IMG_NAME="未找到（请检查编译是否成功）"
    IMG_SIZE="未知"
fi

# ===================================================================
# 4. 获取编译日期与源码 commit 信息
# ===================================================================
BUILD_DATE=$(date +'%Y-%m-%d %H:%M:%S')
SOURCE_COMMIT=$(git rev-parse --short HEAD)
SOURCE_MSG=$(git log -1 --pretty=format:'%s')

# ===================================================================
# 5. 从 .config 提取启用的插件清单
# -------------------------------------------------------------------
# 思路：grep 出所有 CONFIG_PACKAGE_xxx=y 的行，去掉前缀，按类别分组
#   - LuCI 应用（luci-app-*）：用户可见的 LuCI 后台插件
#   - kmod-*：内核模块（如 turboacc 的 kmod-fast-classifier）
#   - 其他：ddnsto/adguardhome 等独立服务
# 一行一个插件，避免拥挤
# ===================================================================

# 提取所有启用的包名（去掉 CONFIG_PACKAGE_ 前缀和 =y 后缀）
ALL_PKGS=$(grep '^CONFIG_PACKAGE_.*=y' .config | sed 's/^CONFIG_PACKAGE_//;s/=y$//' | sort -u)

# 分类一：LuCI 应用插件（用户在后台能看到的）
LUCI_APPS=$(echo "$ALL_PKGS" | grep '^luci-app-' | sort -u)

# 分类二：内核模块 kmod-（TurboACC、网卡驱动等）
KMOD_PKGS=$(echo "$ALL_PKGS" | grep '^kmod-' | sort -u)

# 分类三：独立服务（不是 luci-app、不是 kmod 的用户态服务）
SERVICE_PKGS=$(echo "$ALL_PKGS" | grep -v '^luci-app-' | grep -v '^kmod-' | grep -v '^luci-mod-' | grep -v '^luci-theme-' | grep -v '^luci-i18n-' | grep -vE '^(base-files|busybox|dnsmasq-base|dnsmasq|dropbear|firewall|iptables|libc|libustream|lua|netifd|opkg|ubox|ubus|uci|uclient-fetch|urandom-seed|wpad-mini|wpad|rpcd|uhttpd|luci$|luci-base$|luci-mod-admin-full$|luci-mod-system$|luci-mod-network$|luci-mod-status$|libuclient|libustream-wolfssl|libustream-mbedtls|luci-ssl|px5g-mbedtls|kmod-ipt-core)' | sort -u)

# 分类四：LuCI 主题
THEME_PKGS=$(echo "$ALL_PKGS" | grep '^luci-theme-' | sort -u)

# ===================================================================
# 6. 写入 markdown 到 INFO_FILE
# ===================================================================
{
    echo "# OpenWrt X86_64 云编译固件"
    echo ""
    echo "> 此固件由 GitHub Actions 自动编译并发布，可直接下载使用。"
    echo ""
    echo "## 基本信息"
    echo ""
    echo "| 项目 | 值 |"
    echo "|------|-----|"
    echo "| 固件版本 | \`${FW_VERSION}\` |"
    echo "| 内核版本 | \`Linux ${KERNEL_VER}\` |"
    echo "| 编译日期 | ${BUILD_DATE} (北京时间) |"
    echo "| 源码 commit | \`${SOURCE_COMMIT}\` — ${SOURCE_MSG} |"
    echo "| 目标平台 | X86/64 |"
    echo "| 文件系统 | squashfs + overlay |"
    echo "| overlay 空间 | 约 2GB（已预留） |"
    echo "| 镜像格式 | IMG（含 EFI 引导，无需 VHDX/VMDK） |"
    echo "| 镜像文件 | \`${IMG_NAME}\` |"
    echo "| 镜像大小 | ${IMG_SIZE} |"
    echo ""
    echo "## 登录信息"
    echo ""
    echo "| 项目 | 值 |"
    echo "|------|-----|"
    echo "| LAN IP | \`192.168.1.1\` |"
    echo "| 登录账号 | \`root\` |"
    echo "| 登录密码 | 默认空（首次登录强制设置） |"
    echo "| 管理面板 | http://192.168.1.1 |"
    echo ""
    echo "## 使用方法"
    echo ""
    echo "1. 下载下面的 \`*.img\` 镜像文件"
    echo "2. 使用 Rufus（Windows）或 \`dd\`（Linux/macOS）写入 U 盘或硬盘"
    echo "   - Windows：用 Rufus 选择镜像，模式选 \`DD 模式\`"
    echo "   - Linux：\`gunzip\` 解压后 \`sudo dd if=xxx.img of=/dev/sdX bs=4M\`"
    echo "3. 写入完成后插入设备启动，浏览器访问 http://192.168.1.1"
    echo "4. 用 \`root\` 账号登录，首次登录会提示设置密码"
    echo ""
    echo "## 启用插件清单"
    echo ""
    echo "> 每行一个插件，便于查阅"
    echo ""
    echo "### LuCI 应用插件"
    echo ""
    if [ -n "$LUCI_APPS" ]; then
        echo "$LUCI_APPS" | while IFS= read -r pkg; do
            [ -n "$pkg" ] && echo "- \`${pkg}\`"
        done
    else
        echo "- 无"
    fi
    echo ""
    echo "### LuCI 主题"
    echo ""
    if [ -n "$THEME_PKGS" ]; then
        echo "$THEME_PKGS" | while IFS= read -r pkg; do
            [ -n "$pkg" ] && echo "- \`${pkg}\`"
        done
    else
        echo "- 无"
    fi
    echo ""
    echo "### 内核模块（kmod）"
    echo ""
    if [ -n "$KMOD_PKGS" ]; then
        echo "$KMOD_PKGS" | while IFS= read -r pkg; do
            [ -n "$pkg" ] && echo "- \`${pkg}\`"
        done
    else
        echo "- 无"
    fi
    echo ""
    echo "### 独立服务"
    echo ""
    if [ -n "$SERVICE_PKGS" ]; then
        echo "$SERVICE_PKGS" | while IFS= read -r pkg; do
            [ -n "$pkg" ] && echo "- \`${pkg}\`"
        done
    else
        echo "- 无"
    fi
    echo ""
    echo "---"
    echo ""
    echo "## 校验文件"
    echo ""
    echo "下载 \`sha256sums\` 文件后，可用以下命令校验镜像完整性："
    echo ""
    echo '```bash'
    echo "sha256sum -c sha256sums --ignore-missing"
    echo '```'
    echo ""
    echo "## 反馈与定制"
    echo ""
    echo "- 想增删插件：编辑仓库 \`config/custom-packages.conf\`"
    echo "- 想改默认配置（LAN IP、密码、主题）：编辑 \`scripts/diy-part2.sh\`"
    echo "- 想加更多第三方插件源：编辑 \`scripts/diy-part1.sh\`"
    echo "- 想手动触发编译：在仓库 Actions 页面点击 \`Run workflow\`"
} > "$INFO_FILE"

echo "[build-info.sh] 固件信息已生成到 $INFO_FILE"
echo "=================================================="
echo "[build-info.sh] 信息文件预览："
echo "=================================================="
cat "$INFO_FILE"
