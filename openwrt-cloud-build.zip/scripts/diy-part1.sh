#!/bin/bash
# ===================================================================
# diy-part1.sh：编译前自定义脚本（在 feeds update 之前执行）
# -------------------------------------------------------------------
# 作用：把第三方插件源（feeds 源）追加到 feeds.conf.default
#       feeds.conf.default 是 LEDE 的"软件源配置文件"，每行格式：
#       源名称  仓库URL  分支/commit
#       在 feeds update 时会按这里列出的源拉取代码
# -------------------------------------------------------------------
# 你可以在这个文件里追加更多第三方插件源，例如：
#   src-link myplugin https://github.com/yourname/yourplugin
# ===================================================================

# 进入 OpenWrt 源码目录（workflow 把源码克隆到 $HOME/openwrt）
cd $HOME/openwrt || exit 1

# -------------------------------------------------------------------
# 追加 DDNSTO 插件源（linkease 官方仓库）
# DDNSTO 是国内常用的内网穿透服务，提供远程访问路由器后台能力
# -------------------------------------------------------------------
echo "src-link ddnsto https://github.com/linkease/ddnsto-openwrt-nikic" >> feeds.conf.default

# -------------------------------------------------------------------
# 追加 AdGuardHome 插件源（rufengsu 维护的 OpenWrt 版）
# AdGuardHome 是开源的 DNS 去广告 + DNS 加速服务
# -------------------------------------------------------------------
echo "src-link adguardhome https://github.com/rufengsu/adguardhome-openwrt" >> feeds.conf.default

# -------------------------------------------------------------------
# 追加 Argon 主题源（jerrykuku 官方维护）
# Argon 是 OpenWrt LuCI 后台美化主题，社区最流行
# -------------------------------------------------------------------
echo "src-link argon https://github.com/jerrykuku/luci-theme-argon" >> feeds.conf.default
# Argon 主题配套的配置面板，可在线换壁纸、调色
echo "src-link argon-config https://github.com/jerrykuku/luci-app-argon-config" >> feeds.conf.default

# -------------------------------------------------------------------
# 注意：
#   - appfilter（应用过滤）和 turboacc 已包含在 LEDE 自带 feeds 中，
#     无需额外追加源，只要在 custom-packages.conf 里启用即可
#   - 想新增第三方插件源，仿照上面格式追加一行 src-link 即可
# -------------------------------------------------------------------

echo "[diy-part1.sh] 第三方 feeds 源已追加完成"
