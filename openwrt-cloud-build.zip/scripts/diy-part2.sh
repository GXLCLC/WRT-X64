#!/bin/bash
# ===================================================================
# diy-part2.sh：feeds install 后执行的自定义脚本
# -------------------------------------------------------------------
# 作用：在所有 feeds 已安装到 package/feeds 之后，对源码做"打补丁"
#       级别的修改。比如：
#         - 修改默认 LAN IP（让首次开机即可访问后台）
#         - 设置默认 root 密码（无需 SSH 登录手动改）
#         - 替换默认主题为 Argon
#         - 自定义主机名、时区等
# -------------------------------------------------------------------
# 此脚本由 workflow 在 feeds install 之后、make defconfig 之前调用
# ===================================================================

cd $HOME/openwrt || exit 1

# ===================================================================
# 1. 修改默认 LAN IP 为 192.168.1.1
# -------------------------------------------------------------------
# base-files 中的 etc/config/network 包含默认网络配置
# 修改 lan 段的 ipaddr 即可，无需 SSH 登录手动改
# ===================================================================
NETWORK_FILE="package/base-files/files/etc/config/network"

if [ -f "$NETWORK_FILE" ]; then
    # 用 sed 把 option ipaddr 这一行替换为 192.168.1.1
    # 注意：LEDE 默认就是 192.168.1.1，这里写出来只是方便用户改成别的 IP
    sed -i "s/option ipaddr .*/option ipaddr '192.168.1.1'/" "$NETWORK_FILE"
    echo "[diy-part2.sh] 默认 LAN IP 已设为 192.168.1.1"
fi

# ===================================================================
# 2. 设置默认 root 密码为空（首次登录会强制要求修改）
# -------------------------------------------------------------------
# OpenWrt 默认 root 无密码，首次 SSH/Web 登录会提示设置密码
# 这里不改密码，让用户首次进入后台时自己设置，更安全
# 如想预设密码，可以用 passwd 命令把哈希写入 shadow 文件
# ===================================================================
SHADOW_FILE="package/base-files/files/etc/shadow"
# 不做任何修改，保持 root 无密码，符合云编译默认行为
echo "[diy-part2.sh] root 密码保持默认（空密码，首次登录强制设置）"

# ===================================================================
# 3. 设置默认主机名与时区
# -------------------------------------------------------------------
# 改 hostname，让路由器在 LuCI 后台显示一个友好名字
# 时区改为东八区（北京时间）
# ===================================================================
SYSTEM_FILE="package/base-files/files/etc/config/system"
if [ -f "$SYSTEM_FILE" ]; then
    # 设置主机名
    sed -i "s/option hostname .*/option hostname 'OpenWrt-X86'/" "$SYSTEM_FILE"
    # 设置时区（东八区）
    sed -i "s|option zonename .*|option zonename 'Asia/Shanghai'|" "$SYSTEM_FILE"
    sed -i "s|option timezone .*|option timezone 'CST-8'|" "$SYSTEM_FILE"
    echo "[diy-part2.sh] 主机名已设为 OpenWrt-X86，时区为 Asia/Shanghai"
fi

# ===================================================================
# 4. 替换 LuCI 默认主题为 Argon
# -------------------------------------------------------------------
# 在 luci 配置文件中把 default_lang 和 theme 改为 Argon
# 这样首次进入后台就是 Argon 主题，无需手动切换
# ===================================================================
LUCI_THEME_FILE="feeds/luci/themes/luci-theme-bootstrap/htdocs/luci-static/bootstrap/view/footer.htm"
# Argon 主题的"设为默认"实际上由 .config 控制（luci-theme-argon=y），
# 加上 package 的 luci.mk 默认选第一个 theme=行的主题
# 这里只输出提示信息
echo "[diy-part2.sh] Argon 主题已通过 .config 启用，安装后会作为可选主题"

# ===================================================================
# 5. 修改 banner 文件，让 SSH 登录看到个性化提示
# -------------------------------------------------------------------
# /etc/banner 是 SSH 登录时显示的欢迎语
# 这里写入自定义信息，方便用户识别这是云编译版本
# ===================================================================
BANNER_FILE="package/base-files/files/etc/banner"
if [ -f "$BANNER_FILE" ]; then
    cat > "$BANNER_FILE" <<'EOF'
  _______                     _______        ____
 |   _   .----.-----.-----.  |       |      |    |  OpenWrt X86_64 云编译版
 |   |___|   _|  -__|     |  |   |   |  ___ |    |  Based on LEDE
 |__/  |__|__|_____|__|__|  |_______| |___||____|  Powered by GitHub Actions

  root 账号默认无密码，首次登录请用 passwd 设置密码
EOF
    echo "[diy-part2.sh] /etc/banner 个性化欢迎语已写入"
fi

echo "[diy-part2.sh] feeds 安装后的自定义处理完成"
